﻿using Dapper;
using Microsoft.AspNetCore.Connections;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Data.SqlClient;
using System.Data;
using UserRagistration.Data;
using UserRagistration.Models;
using UserRagistration.Repositories.Interfaces;

namespace UserRagistration.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly IDbConnectionFactory _dbConnectionFactory;

        public ProductRepository(IDbConnectionFactory dbConnectionFactory)
        {
            _dbConnectionFactory = dbConnectionFactory;
        }
        public async Task<IReadOnlyList<ProductMaster>> GetAllAsync(CancellationToken cancellationToken = default)
        {
            using var connection = _dbConnectionFactory.CreateConnection();

            var command = new CommandDefinition(
                "dbo.sp_ProductMaster_GetAll",
                commandType: CommandType.StoredProcedure,
                cancellationToken: cancellationToken);

            var products = await connection.QueryAsync<ProductMaster>(command);

            return products.AsList();
        }

        public async Task<bool> TryInsertAsync(ProductMaster product, CancellationToken cancellationToken = default)
        {
            using var connection = _dbConnectionFactory.CreateConnection();

            var parameters = new
            {
                product.ProductCode,
                product.ProductName,
                product.Category,
                product.UnitPrice,
                product.Quantity
            };

            var command = new CommandDefinition(
                "dbo.sp_ProductMaster_Import",
                parameters, commandType: CommandType.StoredProcedure, cancellationToken: cancellationToken);

            try
            {
                int inserted = await connection.QuerySingleAsync<int>(command);
                return inserted == 1;
            }
            catch (SqlException ex) when (ex.Number is 2601 or 2627)
            {

                return false;
            }
        }
    }
}
