﻿using UserRagistration.Data;
using UserRagistration.Models;
using UserRagistration.Repositories.Interfaces;
using Dapper;

namespace UserRagistration.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly IDbConnectionFactory _dbConnectionFactory;

        public UserRepository(IDbConnectionFactory dbConnectionFactory)
        {
            _dbConnectionFactory = dbConnectionFactory;
        }

        public async Task<int> GetUserCountAsync()
        {
            const string sql = "SELECT COUNT(*) FROM UserRegistrations";
            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<int>(sql);
        }

        public async Task<bool> EmailExistsAsync(string email)
        {
            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<bool>("sp_CheckUserByEmailId", new { Email = email },
                commandType: System.Data.CommandType.StoredProcedure);
        }

        public async Task<UserRegistration?> GetByEmailAsync(string email)
        {
            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.QuerySingleOrDefaultAsync<UserRegistration>("sp_GetUserByEmailId", new { Email = email },
                commandType: System.Data.CommandType.StoredProcedure);
        }

        public async Task<int> AddUserRegistrationAsnc(UserRegistration model)
        {
            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<int>(
                "dbo.sp_AddUserRegistration",
                new
                {
                    FullName = model.FullName,
                    Email = model.Email,
                    Mobile = model.Mobile,
                    Password = model.Password,
                    ConfirmPassword = model.ConfirmPassword
                },
                commandType: System.Data.CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<UserRegistration>> ListUserRegistrationsAsync()
        {
            const string sql = "SELECT FullName, Email, Mobile FROM UserRegistrations";
            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.QueryAsync<UserRegistration>(sql);
        }
    }
}
