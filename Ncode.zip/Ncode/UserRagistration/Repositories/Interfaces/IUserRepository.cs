﻿using UserRagistration.Models;

namespace UserRagistration.Repositories.Interfaces
{
    public interface IUserRepository
    {
        Task<int> GetUserCountAsync();
        Task<bool> EmailExistsAsync(string email);
        Task<UserRegistration?> GetByEmailAsync(string email);
        Task<int> AddUserRegistrationAsnc(UserRegistration model);
        Task<IEnumerable<UserRegistration>> ListUserRegistrationsAsync();
    }
}
