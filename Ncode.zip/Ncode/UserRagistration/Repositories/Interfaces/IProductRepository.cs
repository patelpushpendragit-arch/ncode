﻿using UserRagistration.Models;

namespace UserRagistration.Repositories.Interfaces
{
    public interface IProductRepository
    {
        Task<IReadOnlyList<ProductMaster>> GetAllAsync(CancellationToken cancellationToken = default);

        Task<bool> TryInsertAsync(ProductMaster product, CancellationToken cancellationToken = default);
    }
}
