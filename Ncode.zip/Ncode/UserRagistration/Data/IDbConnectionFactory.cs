﻿using System.Data;

namespace UserRagistration.Data
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection();
    }
}
