﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UserRagistration.Services.Interfaces;

namespace UserRagistration.Controllers
{
    
    public class UsersController : Controller
    {
        private readonly IUserServices _userServices;

        public UsersController(IUserServices userServices)
        {
            _userServices = userServices;
        }
        [Authorize]
        [HttpGet("/api/users")]
        public async Task<IActionResult> Index()
        {
            var data = await _userServices.GetRegisteredUserAsync();
            return Ok(new
            {
                Id = User.FindFirstValue(JwtRegisteredClaimNames.Sub),
                Email = User.FindFirstValue(JwtRegisteredClaimNames.Email),
                Name = User.FindFirstValue(JwtRegisteredClaimNames.Name),
                Data = data
            });
        }

        [HttpGet("/Users")]
        public IActionResult IndexPage()
        {
            return View("Index");
        }         
    }
}
