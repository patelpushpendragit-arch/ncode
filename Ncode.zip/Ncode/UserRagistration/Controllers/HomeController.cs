using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using UserRagistration.DTOs;
using UserRagistration.Models;
using UserRagistration.Services.Interfaces;

namespace UserRagistration.Controllers
{
    public class HomeController : Controller
    {
        private readonly IUserServices _userServices;
        private readonly IProductMasterImportService _importService;

        public HomeController(IUserServices userServices, IProductMasterImportService importService)
        {
            _userServices = userServices;
            _importService = importService;
        }
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Upload()
        {
            return View(new ProductMasterUploadDto());
        }
        [HttpGet]
        public async Task<IActionResult> Products(CancellationToken cancellationToken)
        {
            var products = await _importService.GetAllAsync(cancellationToken);
            return View(products);
        }
         
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
