﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UserRagistration.DTOs;
using UserRagistration.Services.Interfaces;

namespace UserRagistration.Controllers
{
    [ApiController]
    [Route("api/products")]
    [Authorize]
    public class ProductsController : ControllerBase
    {
        private const long MaxFileSize = 10 * 1024 * 1024;

        private readonly IConfiguration _configuration;
        private readonly IProductMasterImportService _importService;

        public ProductsController(IConfiguration configuration, IProductMasterImportService importService)
        {
            _configuration = configuration;
            _importService = importService;
        }


        [HttpPost("upload")]
        [Authorize]
        [Consumes("multipart/form-data")]
        [RequestSizeLimit(MaxFileSize)]
        public async Task<IActionResult> UploadProducts([FromForm] IFormFile? file, CancellationToken cancellationToken)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new
                {
                    message = "Please select an Excel file."
                });
            }

            if (file.Length > MaxFileSize)
            {
                return BadRequest(new
                {
                    message = "File size cannot exceed 10 MB."
                });
            }

            if (!string.Equals(Path.GetExtension(file.FileName), ".xlsx", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(new
                {
                    message = "Only .xlsx files are allowed."
                });
            }

            try
            {
                await using var stream = file.OpenReadStream();

                var result = await _importService.ImportAsync(stream, cancellationToken);

                return Ok(new
                {
                    message = "Product import completed.",
                    summary = new
                    {
                        result.RecordsProcessed,
                        result.SuccessfullyImported,
                        result.Rejected
                    },
                    errors = result.Errors
                });
            }
            catch (InvalidDataException ex)
            {
                return BadRequest(new
                {
                    message = ex.Message
                });
            }
            catch (OperationCanceledException)
                when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "An error occurred while importing products."
                });
            }

        }
        [HttpGet]
        public async Task<IActionResult> GetAll(CancellationToken cancellationToken)
        {
            var products = await _importService.GetAllAsync(cancellationToken);
            return Ok(products);
        }
    }
}
