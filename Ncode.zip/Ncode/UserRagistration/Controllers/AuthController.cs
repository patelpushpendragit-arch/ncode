using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using UserRagistration.DTOs;
using UserRagistration.Services.Interfaces;

namespace UserRagistration.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly IUserServices _userServices;

        public AuthController(IAuthService authService, IUserServices userServices)
        {
            _authService = authService;
            _userServices = userServices;
        }
       
        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> Create([FromBody] CreateUserDtos dto)
        {
            if (!ModelState.IsValid)
            {
                return ValidationProblem(ModelState);
            }

            var userId = await _userServices.AddUserRegistrationAsnc(dto);
            if (userId == 0)
            {
                return Conflict(new { message = "An account with this email address is already registered." });
            }

            return StatusCode(StatusCodes.Status201Created, new
            {
                userId,
                message = "User registration successful."
            });
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginRequestDto request)
        {
            var result = await _authService.LoginAsync(request);
            if (result is null)
            {
                return Unauthorized(new { message = "Invalid email or password." });
            }
            return Ok(result);
        }

        [Authorize]
        [HttpGet("me")]
        public IActionResult Me()
        {
            return Ok(new
            {
                Id = User.FindFirstValue(JwtRegisteredClaimNames.Sub),
                Email = User.FindFirstValue(JwtRegisteredClaimNames.Email),
                Name = User.FindFirstValue(JwtRegisteredClaimNames.Name)
            });
        }
    }
}
