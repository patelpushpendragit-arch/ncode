﻿using UserRagistration.DTOs;
using UserRagistration.Models;

namespace UserRagistration.Helper
{
    public static class ModelMapper
    {
        public static IEnumerable<UserListDtos> Map(IEnumerable<UserRegistration> data)
        {
            if (data == null)
            {
                return Enumerable.Empty<UserListDtos>();
            }

            return data.Select(user => new UserListDtos
            {
                FullName = user.FullName,
                Email = user.Email,
                Mobile = user.Mobile,
            }).ToList();

        }
        public static IReadOnlyList<ProductMasterDto> MapMaster(IReadOnlyList<ProductMaster> data)
        {
            if (data == null)
            {
                return null;
            }

            return data.Select(user => new ProductMasterDto
            {
                ProductCode = user.ProductCode,
                ProductName = user.ProductName,
                Category = user.Category,
                UnitPrice = user.UnitPrice,
                Quantity = user.Quantity
            }).ToList();

        }
    }
}
