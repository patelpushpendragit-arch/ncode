using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using UserRagistration.DTOs;
using UserRagistration.Repositories.Interfaces;
using UserRagistration.Services.Interfaces;

namespace UserRagistration.Services
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepository;
        private readonly IPasswordHasher<string> _passwordHasher;
        private readonly IConfiguration _configuration;

        public AuthService(IUserRepository userRepository, IPasswordHasher<string> passwordHasher, IConfiguration configuration)
        {
            _userRepository = userRepository;
            _passwordHasher = passwordHasher;
            _configuration = configuration;
        }

        public async Task<LoginResponseDto?> LoginAsync(LoginRequestDto request)
        {
            ArgumentNullException.ThrowIfNull(request);

            var email = request.Email.Trim().ToLowerInvariant();
            var user = await _userRepository.GetByEmailAsync(email);
            if (user is null || string.IsNullOrEmpty(user.Password))
            {
                return null;
            }

            var verificationResult = _passwordHasher.VerifyHashedPassword(
                user.Email,
                user.Password,
                request.Password);

            if (verificationResult == PasswordVerificationResult.Failed)
            {
                return null;
            }

            var issuer = _configuration["Jwt:Issuer"]
                ?? throw new InvalidOperationException("JWT issuer is not configured.");
            var audience = _configuration["Jwt:Audience"]
                ?? throw new InvalidOperationException("JWT audience is not configured.");
            var signingKey = _configuration["Jwt:SigningKey"]
                ?? throw new InvalidOperationException("JWT signing key is not configured.");
            var expirationMinutes = _configuration.GetValue<int>("Jwt:ExpirationMinutes", 60);
            if (expirationMinutes <= 0)
            {
                throw new InvalidOperationException("JWT expiration must be greater than zero.");
            }

            var now = DateTime.UtcNow;
            var expiresAt = now.AddMinutes(expirationMinutes);
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim(JwtRegisteredClaimNames.Name, user.FullName)
            };
            var credentials = new SigningCredentials(
                new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey)),
                SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer,
                audience,
                claims,
                notBefore: now,
                expires: expiresAt,
                signingCredentials: credentials);

            return new LoginResponseDto
            {
                AccessToken = new JwtSecurityTokenHandler().WriteToken(token),
                ExpiresAtUtc = expiresAt
            };
        }
    }
}
