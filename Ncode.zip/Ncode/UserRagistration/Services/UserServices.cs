﻿using Microsoft.AspNetCore.Identity;
using UserRagistration.DTOs;
using UserRagistration.Helper;
using UserRagistration.Models;
using UserRagistration.Repositories.Interfaces;
using UserRagistration.Services.Interfaces;

namespace UserRagistration.Services
{
    public class UserServices : IUserServices
    {
        private readonly IUserRepository _userRepository;
        private readonly IPasswordHasher<string> _passwordHasher;

        public UserServices(IUserRepository userRepository, IPasswordHasher<string> passwordHasher)
        {
            _userRepository = userRepository;
            _passwordHasher = passwordHasher;
        }

        public async Task<IEnumerable<UserListDtos>> GetRegisteredUserAsync()
        {
            var data = await _userRepository.ListUserRegistrationsAsync();
            IEnumerable<UserListDtos> mappedDtos = ModelMapper.Map(data);
            return mappedDtos;

        } 

        public async Task<int> AddUserRegistrationAsnc(CreateUserDtos dto)
        {
            if(dto == null)
            {
                return 0;
            }

            var email = dto.Email.Trim().ToLowerInvariant();
            if (await _userRepository.EmailExistsAsync(email))
            {
                return 0;
            }

            var userRegistration = new UserRegistration
            {
                Id = 0,
                FullName = dto.FullName,
                Email = email,
                Mobile = dto.Mobile,
                Password = _passwordHasher.HashPassword(email, dto.Password),
                ConfirmPassword = _passwordHasher.HashPassword(email, dto.ConfirmPassword)
            };
            return await _userRepository.AddUserRegistrationAsnc(userRegistration);
        }
    }
}
