﻿using ClosedXML.Excel;
using System.Globalization;
using UserRagistration.DTOs;
using UserRagistration.Helper;
using UserRagistration.Models;
using UserRagistration.Repositories.Interfaces;
using UserRagistration.Services.Interfaces;

namespace UserRagistration.Services
{
    public class ProductMasterImportService : IProductMasterImportService
    {
        private readonly IProductRepository _repository;

        public ProductMasterImportService(IProductRepository repository)
        {
            _repository = repository;
        }
        public async Task<ProductMasterUploadResult> ImportAsync(Stream fileStream, CancellationToken cancellationToken = default)
        {
            var result = new ProductMasterUploadResult();

            using var workbook = new XLWorkbook(fileStream);
            var sheet = workbook.Worksheets.FirstOrDefault()
                ?? throw new InvalidDataException("No worksheet found.");

            var lastRow = sheet.LastRowUsed()?.RowNumber() ?? 0;
            var lastColumn = sheet.LastColumnUsed()?.ColumnNumber() ?? 0;

            if (lastRow == 0)
                throw new InvalidDataException("The Excel file is empty.");

            string[] headers =
            {
            "ProductCode", "ProductName", "Category",
            "UnitPrice", "Quantity"
            };

            if (lastColumn != headers.Length)
                throw new InvalidDataException("The file must contain exactly five columns.");

            for (int col = 1; col <= headers.Length; col++)
            {
                if (!string.Equals(sheet.Cell(1, col).GetString().Trim(), headers[col - 1],
                    StringComparison.OrdinalIgnoreCase))
                {
                    throw new InvalidDataException($"Invalid header in column {col}. " + $"Expected {headers[col - 1]}.");
                }
            }

            var rows = new List<ImportRow>();

            for (int r = 2; r <= lastRow; r++)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var cells = Enumerable.Range(1, 5)
                    .Select(c => sheet.Cell(r, c))
                    .ToArray();

                if (cells.All(c => c.IsEmpty()))
                    continue;

                result.RecordsProcessed++;

                var row = new ImportRow
                {
                    RowNumber = r,
                    ProductCode = cells[0].GetString().Trim(),
                    ProductName = cells[1].GetString().Trim(),
                    Category = cells[2].GetString().Trim()
                };

                ValidateText(cells[0], row.ProductCode, "ProductCode", 50, row.Errors);

                ValidateText(cells[1], row.ProductName, "ProductName", 200, row.Errors);

                ValidateText(cells[2], row.Category, "Category", 100, row.Errors);

                if (!decimal.TryParse(cells[3].GetString().Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out var price))
                {
                    row.Errors.Add("UnitPrice must be a valid decimal.");
                }
                else if (price < 0)
                {
                    row.Errors.Add("UnitPrice must be >= 0.");
                }
                else if (decimal.Round(price, 2) != price)
                {
                    row.Errors.Add("UnitPrice cannot have more than 2 decimal places.");
                }
                else
                {
                    row.UnitPrice = price;
                }

                if (!int.TryParse(cells[4].GetString().Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture,
                    out var quantity))
                {
                    row.Errors.Add("Quantity must be a valid integer.");
                }
                else if (quantity < 0)
                {
                    row.Errors.Add("Quantity must be >= 0.");
                }
                else
                {
                    row.Quantity = quantity;
                }

                rows.Add(row);
            }

            var duplicates = rows.Where(r => !string.IsNullOrWhiteSpace(r.ProductCode))
                .GroupBy(r => r.ProductCode, StringComparer.OrdinalIgnoreCase)
                .Where(g => g.Count() > 1).Select(g => g.Key).ToHashSet(StringComparer.OrdinalIgnoreCase);

            foreach (var row in rows)
            {
                if (duplicates.Contains(row.ProductCode))
                {
                    row.Errors.Add($"ProductCode '{row.ProductCode}' is duplicated " +
                        "within the uploaded file.");
                }
            }

            foreach (var row in rows)
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (row.Errors.Count > 0)
                {
                    Reject(result, row);
                    continue;
                }

                var product = new ProductMaster
                {
                    ProductCode = row.ProductCode,
                    ProductName = row.ProductName,
                    Category = row.Category,
                    UnitPrice = row.UnitPrice,
                    Quantity = row.Quantity
                };

                bool inserted = await _repository.TryInsertAsync(product, cancellationToken);

                if (inserted)
                {
                    result.SuccessfullyImported++;
                }
                else
                {
                    row.Errors.Add($"ProductCode '{row.ProductCode}' already exists " + "in the database.");
                    Reject(result, row);
                }
            }

            return result;
        }

        private static void ValidateText(IXLCell cell, string value, string field, int maxLength, List<string> errors)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                errors.Add($"{field} is required.");
                return;
            }

            if (cell.DataType != XLDataType.Text)
                errors.Add($"{field} must be stored as text in Excel.");

            if (value.Length > maxLength)
                errors.Add($"{field} cannot exceed {maxLength} characters.");
        }

        private static void Reject(ProductMasterUploadResult result, ImportRow row)
        {
            result.Rejected++;

            result.Errors.Add(new ProductImportError
            {
                RowNumber = row.RowNumber,
                ProductCode = row.ProductCode,
                ErrorMessage = string.Join(" ", row.Errors)
            });
        }

        public async Task<IReadOnlyList<ProductMasterDto>> GetAllAsync(CancellationToken cancellationToken = default)
        {
            var products = await _repository.GetAllAsync(cancellationToken);
            return ModelMapper.MapMaster(products);
        }
    }
}
