﻿using UserRagistration.DTOs;

namespace UserRagistration.Services.Interfaces
{
    public interface IProductMasterImportService
    {
        Task<ProductMasterUploadResult> ImportAsync(Stream fileStream, CancellationToken cancellationToken = default);
        Task<IReadOnlyList<ProductMasterDto>> GetAllAsync(CancellationToken cancellationToken = default);


    }
}
