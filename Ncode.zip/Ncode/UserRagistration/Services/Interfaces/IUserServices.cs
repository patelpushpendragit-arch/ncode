﻿using UserRagistration.DTOs;

namespace UserRagistration.Services.Interfaces
{
    public interface IUserServices
    {
        Task<IEnumerable<UserListDtos>> GetRegisteredUserAsync();
        Task<int> AddUserRegistrationAsnc(CreateUserDtos dto);
    }
}
