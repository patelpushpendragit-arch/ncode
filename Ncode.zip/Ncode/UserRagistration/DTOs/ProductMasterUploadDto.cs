﻿namespace UserRagistration.DTOs
{
    public class ProductMasterUploadDto
    {
        public IFormFile? File { get; set; }

        public ProductMasterUploadResult? Result { get; set; }

        public string? Message { get; set; }
    }
    public class ProductMasterRow
    {
        public string ProductCode { get; set; } = "";
        public string ProductName { get; set; } = "";
        public string Category { get; set; } = "";
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
    }

    public class ProductImportError
    {
        public int RowNumber { get; set; }
        public string ProductCode { get; set; } = "";
        public string ErrorMessage { get; set; } = "";
    }

    public class ProductMasterUploadResult
    {
        public int RecordsProcessed { get; set; }
        public int SuccessfullyImported { get; set; }
        public int Rejected { get; set; }
        public List<ProductImportError> Errors { get; set; } = new();
    }
    public class ImportRow
    {
        public int RowNumber { get; set; }
        public string ProductCode { get; set; } = "";
        public string ProductName { get; set; } = "";
        public string Category { get; set; } = "";
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public List<string> Errors { get; } = new();
    }
}
