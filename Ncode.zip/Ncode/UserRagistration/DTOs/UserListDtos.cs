﻿using System.ComponentModel.DataAnnotations;

namespace UserRagistration.DTOs
{
    public class UserListDtos
    {
        public string FullName { get; set; } = string.Empty;        
        public string Email { get; set; } = string.Empty;        
        public string Mobile { get; set; } = string.Empty;
    }
}
