﻿USE [ncode]
GO
/****** Object:  Table [dbo].[ProductMaster]    Script Date: 10/16/2026 5:26:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductMaster](
	[ProductId] [bigint] IDENTITY(1,1) NOT NULL,
	[ProductCode] [nvarchar](50) NOT NULL,
	[ProductName] [nvarchar](200) NOT NULL,
	[Category] [nvarchar](100) NOT NULL,
	[UnitPrice] [decimal](18, 2) NOT NULL,
	[Quantity] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_ProductMaster_ProductCode] UNIQUE NONCLUSTERED 
(
	[ProductCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserRegistrations]    Script Date: 10/16/2026 5:26:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserRegistrations](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FullName] [nvarchar](250) NOT NULL,
	[Email] [nvarchar](100) NOT NULL,
	[Mobile] [nvarchar](15) NOT NULL,
	[Password] [nvarchar](512) NOT NULL,
	[ConfirmPassword] [nvarchar](512) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ProductMaster]  WITH CHECK ADD  CONSTRAINT [CK_ProductMaster_Quantity] CHECK  (([Quantity]>=(0)))
GO
ALTER TABLE [dbo].[ProductMaster] CHECK CONSTRAINT [CK_ProductMaster_Quantity]
GO
ALTER TABLE [dbo].[ProductMaster]  WITH CHECK ADD  CONSTRAINT [CK_ProductMaster_UnitPrice] CHECK  (([UnitPrice]>=(0)))
GO
ALTER TABLE [dbo].[ProductMaster] CHECK CONSTRAINT [CK_ProductMaster_UnitPrice]
GO
/****** Object:  StoredProcedure [dbo].[sp_AddUserRegistration]    Script Date: 10/16/2026 5:26:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_AddUserRegistration]
	 @FullName nvarchar(250),
	@Email nvarchar(100),
	@Mobile nvarchar(15),
	@Password nvarchar(512),
	@ConfirmPassword nvarchar(512)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   INSERT INTO dbo.UserRegistrations (FullName, Email, Mobile, Password, ConfirmPassword)
VALUES (@FullName, @Email, @Mobile, @Password, @ConfirmPassword);

SELECT CAST(SCOPE_IDENTITY() AS int);

END
GO
/****** Object:  StoredProcedure [dbo].[sp_CheckUserByEmailId]    Script Date: 10/16/2026 5:26:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
Create PROCEDURE [dbo].[sp_CheckUserByEmailId]
	@Email nvarchar(50)
AS
BEGIN
	 
	SET NOCOUNT ON;

	SELECT CAST(CASE WHEN EXISTS (SELECT 1 FROM UserRegistrations WHERE LOWER(Email) = LOWER(@Email)) THEN 1 ELSE 0 END AS bit)
END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetUserByEmailId]    Script Date: 10/16/2026 5:26:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetUserByEmailId]
	@Email nvarchar(50)
AS
BEGIN
	 
	SET NOCOUNT ON;

	SELECT Id, FullName, Email, Password FROM UserRegistrations WHERE LOWER(Email) = LOWER(@Email)
END
GO
/****** Object:  StoredProcedure [dbo].[sp_ProductMaster_GetAll]    Script Date: 10/16/2026 5:26:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROCEDURE [dbo].[sp_ProductMaster_GetAll]
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ProductId,
        ProductCode,
        ProductName,
        Category,
        UnitPrice,
        Quantity       
    FROM dbo.ProductMaster
    ORDER BY ProductId DESC;
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_ProductMaster_Import]    Script Date: 10/16/2026 5:26:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROCEDURE [dbo].[sp_ProductMaster_Import]
    @ProductCode NVARCHAR(50),
    @ProductName NVARCHAR(200),
    @Category NVARCHAR(100),
    @UnitPrice DECIMAL(18,2),
    @Quantity INT
    
AS
BEGIN
   SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF EXISTS
        (
            SELECT 1
            FROM dbo.ProductMaster WITH (UPDLOCK, HOLDLOCK)
            WHERE ProductCode = @ProductCode
        )
        BEGIN
            ROLLBACK TRANSACTION;
            SELECT CAST(0 AS INT);
            RETURN;
        END;

        INSERT INTO dbo.ProductMaster
        (
            ProductCode,
            ProductName,
            Category,
            UnitPrice,
            Quantity            
        )
        VALUES
        (
            @ProductCode,
            @ProductName,
            @Category,
            @UnitPrice,
            @Quantity
        );

        COMMIT TRANSACTION;
        SELECT CAST(1 AS INT);
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH
END;
GO
